# SHINOBI SURVIVORS ALPHA

Original implementation based on stable V12.1, 2026-10-15.

- 6 MUGEN heroes: Naruto, Sasuke, Kakashi, Rock Lee, Neji, Gaara.
- 36 character-specific branching talent trees; each has seven individually named nodes, root + two routes + capstone + apex; 252 unique nodes total.
- 4 starting points, +2 per level, 1/2/3-point node costs.
- Unlocked talents affect actual projectile counts, auto-attack speed, move speed, incoming damage, active character procs and combat output.
- T toggles development tree, 1-6 selects tree tab, click nodes to unlock; hover reveals costs and progression.
- Character selection on main menu.
- Godot native Windows build / QA must be verified after change; not a promise of untested fixes.
- Roster sprites extracted from user-supplied `naruto-mugen-2-50.zip` (RAR). MUGEN artist attribution/license must be checked for public distribution. Private testing only.
