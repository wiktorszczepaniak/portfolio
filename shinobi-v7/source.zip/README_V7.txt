SHINOBI SURVIVORS — SHIPPUDEN V7
PUSTYNIA CZERWONEGO PIASKU

URUCHOMIENIE
Rozpakuj ZIP i uruchom ShinobiSurvivors.exe. Nie jest wymagana instalacja Godota.
Wymagany Windows 10/11, 64-bit, karta graficzna obsługująca OpenGL 3.3.

STEROWANIE
WASD — ruch, automatyczny atak kunai
SHIFT — Kawarimi (podmiana na drewniany pień)
X — Kage Bunshin, po odblokowaniu także Naruto Rendan
1 / 2 / 3 albo kliknięcie — wybór zwoju
Strzałki / TAB + ENTER — wybór zwoju klawiaturą
ESC — pauza
SPACJA albo przycisk TEMPA — zmiana tempa
M — wyciszenie dźwięku
F — mniej efektów / pełne efekty
G — nieśmiertelność
ENTER — rozpoczęcie / ponowna misja
F9 — zachowany skrót testowy do walki z Sasorim

MISJA
Kunai od początku; Rasengan i pozostałe techniki odblokujesz ze zwojów.
Sennin Mode po 02:00 czasu misji, Kyūbi Chakra Mode po 05:30.
Sasori pojawia się po 08:00. Walka obejmuje trzy fazy.
Wybranie zwoju i pauza zatrzymują czas. NORMAL zachowuje tempo wersji V6.

ZMIANY V7
- Ponownie wycięte sprite'y czterech typów ninja z oryginalnych arkuszy.
- Poprawione punkty zaczepienia, odbicia, sekwencje ruchu i ataków.
- Czas animacji niezależny od przyspieszenia misji, wspólna pamięć tekstur.
- Rendan wykorzystuje pełne animacje klonów zamiast rozciągniętych ikon.
- Poprawny pień Kawarimi, proporcje pocisków, cienie i obiekty pustyni.
- Nowe menu, paski HP/chakry, karty zwojów, pauza i raport z misji.
- Polskie znaki i dołączone fonty, jednakowy wygląd na różnych komputerach.

Projekt fanowski. Oryginalne grafiki i dźwięki pochodzą z paczek użytkownika.
DejaVu Fonts: dołączona licencja w źródłach.
