extends Control
## Resolution-independent parchment UI. All text stays native and readable.
const INK := Color("20292c")
const PAPER := Color("f1dfb7")
const CREAM := Color("fff2d3")
const MUTED := Color("aab6ae")
const RED := Color("bd513b")
const GOLD := Color("d5b26a")
const TIERS := [Color("65715a"),Color("277d8a"),Color("825884"),Color("aa741e")]
const TIER_NAMES := ["ZWYKŁY", "RZADKI", "EPICKI", "LEGENDARNY"]
var g
var body: FontFile
var title: FontFile
var mono: FontFile
var hero
var icons: Dictionary = {}
var age := 0.0
var reveal := 0.0
var was_picking := false
var hover_card := -1
var selected_focus := -1
var victory := false
var from_scroll := false

func _ready() -> void:
    size = Vector2(1280,720)
    mouse_filter = Control.MOUSE_FILTER_STOP
    texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    body = _font("body")
    title = _font("title")
    mono = _font("mono")
    hero = load("res://scripts/mugen_actor.gd").new()
    hero.pack_name = "naruto_base"
    hero.position = Vector2(957,523)
    hero.scale = Vector2.ONE * 4.0
    add_child(hero)
    for name in ["naruto_base", "naruto_sage", "naruto_kcm"]:
        var m = JSON.parse_string(FileAccess.get_file_as_string("res://assets/mugen/%s/manifest.json" % name))
        var key: String = m["actions"]["0"][0]["key"]
        icons[name] = g._read_png("res://assets/mugen/%s/%s" % [name,m["sprites"][key]["file"]])
    icons["kunai"] = g.item_art.get("kunai")
    icons["rasengan"] = g.rasengan_frames[0] if not g.rasengan_frames.is_empty() else null

func _font(name: String) -> FontFile:
    var f := FontFile.new()
    f.data = FileAccess.get_file_as_bytes("res://assets/fonts/%s.ttf" % name)
    return f

func _process(dt: float) -> void:
    age += dt
    hero.visible = not g.playing
    if hero.visible: hero.tick(dt)
    if g.picking and not was_picking:
        reveal = 0.0
        selected_focus = -1
    was_picking = g.picking
    reveal += dt
    hover_card = -1
    if g.picking:
        for i in range(g.selected_cards.size()):
            if _card_rect(i).has_point(get_local_mouse_position()): hover_card = i
    mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND if _over_button() else Control.CURSOR_ARROW
    queue_redraw()

func _card_rect(i: int) -> Rect2:
    return Rect2(136+i*352,164,304,450)

func _over_button() -> bool:
    var p := get_local_mouse_position()
    if g.picking: return hover_card >= 0
    if not g.playing:
        return Rect2(82,463,390,62).has_point(p) or Rect2(82,551,470,86).has_point(p)
    if g.finished: return Rect2(467,551,346,56).has_point(p)
    if g.paused: return Rect2(467,400,346,56).has_point(p) or Rect2(467,476,346,42).has_point(p)
    return Rect2(1090,647,160,44).has_point(p)

func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        var p: Vector2 = event.position
        if g.picking:
            for i in range(g.selected_cards.size()):
                if _card_rect(i).has_point(p):
                    g._choose_card(i)
                    accept_event()
                    return
        elif not g.playing:
            if Rect2(82,463,390,62).has_point(p): g._start()
            elif Rect2(82,551,220,36).has_point(p): g._toggle_fx()
            elif Rect2(320,551,230,36).has_point(p): g._toggle_godmode()
            elif Rect2(82,601,220,36).has_point(p): _sound()
        elif g.finished:
            if Rect2(467,551,346,56).has_point(p): g._start()
        elif g.paused:
            if Rect2(467,400,346,56).has_point(p): g.paused = false
            elif Rect2(467,476,346,42).has_point(p): _sound()
        elif Rect2(1090,647,160,44).has_point(p): g.speed_index = (g.speed_index+1)%3
        accept_event()

func _unhandled_key_input(event: InputEvent) -> void:
    if not g.picking or not event is InputEventKey or not event.pressed: return
    if event.keycode in [KEY_LEFT,KEY_RIGHT,KEY_TAB]:
        var step := -1 if event.keycode == KEY_LEFT else 1
        selected_focus = posmod(selected_focus+step,g.selected_cards.size())
        accept_event()
    elif event.keycode == KEY_ENTER and selected_focus >= 0:
        g._choose_card(selected_focus)
        accept_event()

func _sound() -> void:
    g.muted = not g.muted
    g.music_player.volume_db = -80.0 if g.muted else -10.0
    g.sfx_player.volume_db = -80.0 if g.muted else -6.0
    g.special_sfx_player.volume_db = -80.0 if g.muted else -5.0

func _text(s: String, pos: Vector2, px: int = 16, color: Color = CREAM, font: Font = null) -> void:
    draw_string(body if font == null else font,pos,s,HORIZONTAL_ALIGNMENT_LEFT,-1,px,color)

func _center(s: String, x: float, y: float, px: int = 16, color: Color = CREAM, font: Font = null) -> void:
    var f: Font = body if font == null else font
    _text(s,Vector2(x-f.get_string_size(s,HORIZONTAL_ALIGNMENT_LEFT,-1,px).x*0.5,y),px,color,f)

func _wrap(s: String, rect: Rect2, px: int, color: Color, font: Font = null, centered: bool = false) -> int:
    var f: Font = body if font == null else font
    var lines: Array[String] = []
    var line := ""
    for word in s.split(" "):
        var candidate := word if line.is_empty() else line + " " + word
        if f.get_string_size(candidate,HORIZONTAL_ALIGNMENT_LEFT,-1,px).x > rect.size.x and not line.is_empty():
            lines.append(line)
            line = word
        else: line = candidate
    if not line.is_empty(): lines.append(line)
    for i in range(lines.size()):
        if centered: _center(lines[i],rect.get_center().x,rect.position.y+i*(px+7),px,color,f)
        else: _text(lines[i],rect.position+Vector2(0,i*(px+7)),px,color,f)
    return lines.size()

func _box(r: Rect2, color: Color, stroke: Color = Color.TRANSPARENT, radius: int = 4) -> void:
    var b := StyleBoxFlat.new()
    b.bg_color = color
    b.border_color = stroke
    b.set_corner_radius_all(radius)
    if stroke.a > 0: b.set_border_width_all(1)
    draw_style_box(b,r)

func _button(r: Rect2, label: String, primary: bool = true) -> void:
    var hot := r.has_point(get_local_mouse_position())
    var c := RED.lightened(0.10) if hot else RED
    if not primary: c = Color("344145") if hot else Color("293538")
    _box(r,c,GOLD if hot else Color(1,1,1,0.12),3)
    _center(label,r.get_center().x,r.get_center().y+6,17,CREAM)

func _line(y: float, x: float, width: float, color: Color) -> void:
    draw_line(Vector2(x,y),Vector2(x+width,y),color,1.0)

func _seal(at: Vector2, radius: float, color: Color) -> void:
    draw_arc(at,radius,0,TAU,64,color,2.0,true)
    draw_arc(at,radius-6,0,TAU,64,color,1.0,true)
    var pts := PackedVector2Array()
    for i in range(50):
        var t := float(i)/49.0
        pts.append(at+Vector2.from_angle(t*TAU*1.8)*radius*0.70*t)
    draw_polyline(pts,color,2.0,true)
    draw_line(at+Vector2(radius*0.4,radius*0.5),at+Vector2(radius*0.9,radius*0.8),color,2.0,true)

func _bar(r: Rect2, fraction: float, color: Color) -> void:
    _box(r,Color("c9b68e"),Color("b9a780"),2)
    if fraction > 0.0:
        _box(Rect2(r.position+Vector2(2,2),Vector2((r.size.x-4)*clampf(fraction,0,1),r.size.y-4)),color,Color.TRANSPARENT,1)
        draw_line(r.position+Vector2(4,3),r.position+Vector2((r.size.x-4)*clampf(fraction,0,1),3),color.lightened(0.24),1.0)

func _draw() -> void:
    if g == null or body == null: return
    if not g.playing:
        _title()
        return
    if g.finished:
        _result()
    elif g.picking:
        _upgrades()
    elif g.paused:
        _pause()
    else:
        _hud()
        if g.transform_pause > 0:
            draw_rect(Rect2(0,0,1280,720),Color(0.05,0.07,0.08,0.25))
            _center("SENNIN MODE" if g.transform_target_form==1 else "KYŪBI CHAKRA MODE",640,191,35,CREAM,title)
            _center("PRZEBUDZENIE CHAKRY",640,222,13,GOLD,mono)

func _title() -> void:
    draw_rect(Rect2(0,0,1280,720),INK)
    draw_colored_polygon(PackedVector2Array([Vector2(750,0),Vector2(1280,0),Vector2(1280,720),Vector2(595,720)]),PAPER)
    for y in range(20,720,19):
        draw_line(Vector2(760-y*0.21,y),Vector2(1280,y),Color(0.4,0.3,0.19,0.055),1)
    draw_circle(Vector2(974,273),182,RED)
    draw_circle(Vector2(974,273),164,Color("c75940"))
    _seal(Vector2(1126,576),92,Color(0.43,0.34,0.21,0.21))
    _text("NINJA ARTS  /  SHIPPUDEN",Vector2(84,79),15,GOLD,mono)
    _text("SHINOBI",Vector2(77,191),70,CREAM,title)
    _text("SURVIVORS",Vector2(79,260),57,CREAM,title)
    _line(294,82,410,Color("6b7166"))
    _text("PUSTYNIA CZERWONEGO PIASKU",Vector2(84,331),15,GOLD,mono)
    _wrap("Przetrwaj napór ninja. Zbieraj zwoje. Obudź moc Kyūbiego i pokonaj Sasoriego.",Rect2(84,370,438,80),19,MUTED)
    _button(Rect2(82,463,390,62),"ROZPOCZNIJ MISJĘ    ↵")
    _button(Rect2(82,551,220,36),"EFEKTY: " + ("NISKIE" if g.low_fx else "PEŁNE"),false)
    _button(Rect2(320,551,230,36),"NIEŚMIERTELNOŚĆ: " + ("TAK" if g.godmode else "NIE"),false)
    _button(Rect2(82,601,220,36),"DŹWIĘK: " + ("WYŁ." if g.muted else "WŁ."),false)
    _text("WASD  RUCH     SHIFT  KAWARIMI     X  KLONY",Vector2(83,682),12,MUTED,mono)
    _center("UZUMAKI NARUTO",967,570,22,INK,title)
    _center("KUNAI  /  RASENGAN  /  KAGE BUNSHIN",967,601,12,Color("695b47"),mono)
    _center("SENNIN  02:00     •     KYŪBI  05:30",967,646,12,Color("695b47"),mono)
    _text("V7",Vector2(1227,692),12,Color("695b47"),mono)

func _hud() -> void:
    _box(Rect2(22,18,351,97),PAPER,Color("a18b61"),3)
    _box(Rect2(28,24,63,82),INK,Color("bba374"),2)
    var tex: Texture2D = icons[["naruto_base","naruto_sage","naruto_kcm"][g.player_form]]
    var dims := tex.get_size()*1.15
    draw_texture_rect(tex,Rect2(Vector2(61,102)-Vector2(dims.x*0.5,dims.y),dims),false)
    _text("NARUTO",Vector2(102,43),16,INK,title)
    _text("POZ. %02d" % g.level,Vector2(282,42),12,Color("786443"),mono)
    var hp_max: float = g.PLAYER_MAX_HP+float(g.upgrades.get("max_hp",0))*18.0
    _bar(Rect2(102,53,251,16),g.player_hp/hp_max,Color("608363"))
    _bar(Rect2(102,78,251,9),g.exp_value/g.exp_needed,Color("3e99a2"))
    _text("HP %d / %d" % [ceili(g.player_hp),hp_max],Vector2(102,101),10,Color("746348"),mono)
    _text("CHAKRA %d/%d" % [g.exp_value,g.exp_needed],Vector2(238,101),10,Color("746348"),mono)
    _box(Rect2(507,18,266,73),INK,Color("8c835f"),3)
    _center("%02d:%02d" % [int(g.clock/60),int(g.clock)%60],590,65,30,CREAM,mono)
    draw_line(Vector2(659,33),Vector2(659,76),Color("56615b"),1)
    _text("POKONANI",Vector2(680,43),10,MUTED,mono)
    _text(str(g.stat_kills),Vector2(680,69),22,GOLD,mono)
    _box(Rect2(991,18,267,73),PAPER,Color("a18b61"),3)
    _text(["SHIPPUDEN","SENNIN MODE","KYŪBI CHAKRA"][g.player_form],Vector2(1010,45),15,INK,title)
    var next := "Sennin za %ds" % ceili(maxf(0,120-g.clock)) if g.player_form == 0 else "Kyūbi za %ds" % ceili(maxf(0,330-g.clock)) if g.player_form == 1 else "Sasori za %ds" % ceili(maxf(0,480-g.clock)) if not g.boss_active else "Finał misji"
    _text(next,Vector2(1010,70),12,Color("79684e"),mono)
    if g.godmode: _text("NIEŚMIERTELNOŚĆ",Vector2(1010,111),11,CREAM,mono)
    if g.boss_active and not g.boss.is_empty():
        _box(Rect2(393,109,494,54),INK,Color("9e6e51"),3)
        _center("SASORI  /  FAZA %s" % ["I","II","III"][g.boss_phase_reached-1],640,130,13,CREAM,mono)
        _bar(Rect2(408,141,464,9),float(g.boss.hp)/float(g.boss.max_hp),RED)
    _cooldown(Rect2(24,638,205,59),"SHIFT","KAWARIMI",g.dash_cooldown,true)
    _cooldown(Rect2(241,638,223,59),"X","KAGE BUNSHIN",g.clone_cooldown,true)
    _cooldown(Rect2(476,638,209,59),"AUTO","OIROKE",g.oiroke_cd,int(g.upgrades.get("oiroke",0))>0)
    _button(Rect2(1090,647,160,44),g.speed_labels[g.speed_index]+"  [SPACJA]",false)
    _text("ESC  PAUZA",Vector2(929,675),11,CREAM,mono)
    if g.event_time > 0:
        var msg: String = g.event_msg
        var w := minf(920,body.get_string_size(msg,HORIZONTAL_ALIGNMENT_LEFT,-1,16).x+48)
        _box(Rect2(640-w/2,576,w,36),Color(0.10,0.15,0.16,0.92),Color(0.75,0.62,0.36,0.5),3)
        _center(msg,640,600,16,CREAM)

func _cooldown(r: Rect2, key: String, label: String, cooldown: float, unlocked: bool) -> void:
    _box(r,INK,Color("6b725e"),3)
    _box(Rect2(r.position+Vector2(10,13),Vector2(48,31)),Color("394343"),Color("718078"),3)
    _center(key,r.position.x+34,r.position.y+34,11,CREAM,mono)
    _text(label,r.position+Vector2(68,23),11,CREAM,mono)
    _text("ZWÓJ WYMAGANY" if not unlocked else "GOTOWE" if cooldown<=0 else "%.1f s" % cooldown,r.position+Vector2(68,44),12,Color("78bbb4") if unlocked and cooldown<=0 else MUTED,mono)

func _upgrades() -> void:
    draw_rect(Rect2(0,0,1280,720),Color(0.065,0.105,0.115,0.94))
    _seal(Vector2(1160,87),126,Color(0.83,0.72,0.47,0.055))
    _center("ZNALEZIONO STAROŻYTNY ZWÓJ" if from_scroll else "AWANS  /  POZIOM %02d" % g.level,640,62,13,GOLD,mono)
    _center("Wybierz swoją technikę",640,108,35,CREAM,title)
    _center("Jeden zwój. Nowa przewaga w walce.",640,137,15,MUTED)
    for i in range(g.selected_cards.size()):
        var r := _card_rect(i)
        var t := clampf((reveal-float(i)*0.10)*4.0,0.0,1.0)
        var hot := i == hover_card or i == selected_focus
        r.position.y += (1.0-t)*28.0 - (7.0 if hot else 0.0)
        draw_set_transform(r.position)
        _scroll(g.selected_cards[i],i,hot)
        draw_set_transform(Vector2.ZERO)
    _center("1 / 2 / 3   WYBÓR TECHNIKI     •     MOŻESZ TEŻ KLIKNĄĆ ZWÓJ",640,659,12,MUTED,mono)
    _center("CZAS MISJI ZATRZYMANY",640,687,10,Color("71837c"),mono)

func _scroll(card: Dictionary, index: int, hot: bool) -> void:
    var tier: int = card.tier
    var color: Color = TIERS[tier]
    var key: String = card.stat
    var data: Dictionary = g.JUTSU[key]
    _box(Rect2(9,36,290,402),Color(0,0,0,0.27),Color.TRANSPARENT,7)
    _box(Rect2(13,22,278,435),PAPER.lightened(0.05) if hot else PAPER,color if hot else Color("b49d70"),1)
    for y in range(42,424,13):
        draw_line(Vector2(19,y),Vector2(285,y+1),Color(0.4,0.27,0.09,0.033),1)
    draw_rect(Rect2(23,44,258,35),Color(color,0.14))
    _center(TIER_NAMES[tier],152,66,12,color,mono)
    draw_circle(Vector2(152,151),57,Color("e4d0a5"))
    draw_arc(Vector2(152,151),57,0,TAU,64,Color(color,0.40),1.0,true)
    _icon(key,Vector2(152,151),color)
    _wrap(str(data.name),Rect2(29,240,246,60),18,INK,title,true)
    _line(284,37,230,Color("cbb387"))
    _wrap(str(data.desc),Rect2(39,312,226,80),14,Color("62583f"),body,true)
    var current: int = int(g.upgrades.get(key,0))
    var maximum: int = int(data.max)
    var start: float = 152.0-float(maximum)*7.0
    for i in range(maximum):
        _box(Rect2(start+i*15.0,373,9,5),color if i<=current else Color("c9b58b"),Color.TRANSPARENT,1)
    _center("ODKRYJ JUTSU" if current==0 else "POZIOM %d → %d" % [current,current+1],152,399,12,color,mono)
    _box(Rect2(33,412,238,29),color,Color.TRANSPARENT,2)
    _center("[ %d ]   OTWÓRZ ZWÓJ" % (index+1),152,432,12,CREAM,mono)
    for y in [18.0,449.0]:
        _box(Rect2(4,y,296,16),Color("604937"),Color("a17a47"),5)
        draw_line(Vector2(17,y+4),Vector2(286,y+4),Color("a28053"),2.0)
        for x in [4.0,282.0]:
            _box(Rect2(x,y-3,18,22),GOLD,Color("8a683c"),4)
            draw_line(Vector2(x+4,y),Vector2(x+4,y+15),Color("f1d492"),2)

func _icon(key: String, at: Vector2, color: Color) -> void:
    if key in ["clones","naruto_rendan"]:
        var tex: Texture2D = icons["naruto_base"]
        for i in range(3):
            var dims := tex.get_size()*1.12
            draw_texture_rect(tex,Rect2(at+Vector2(-48+i*29,-35),dims),false,Color(1,1,1,0.45 if i!=1 else 1.0))
    elif key.begins_with("kunai"):
        var tex: Texture2D = icons["kunai"]
        draw_texture_rect(tex,Rect2(at-Vector2(42,12),Vector2(84,29.4)),false)
        if key=="kunai_twin": draw_texture_rect(tex,Rect2(at+Vector2(-35,10),Vector2(70,24.5)),false,Color(1,1,1,0.65))
    elif key in ["max_hp","regeneration"]:
        draw_rect(Rect2(at-Vector2(7,28),Vector2(14,56)),color)
        draw_rect(Rect2(at-Vector2(28,7),Vector2(56,14)),color)
    elif key=="speed":
        for i in range(3):
            var x := at.x-28+i*20
            draw_polyline(PackedVector2Array([Vector2(x-10,at.y-20),Vector2(x+7,at.y),Vector2(x-10,at.y+20)]),color,5,true)
    elif key=="oiroke":
        draw_circle(at+Vector2(-12,-7),17,color)
        draw_circle(at+Vector2(12,-7),17,color)
        draw_colored_polygon(PackedVector2Array([at+Vector2(-26,-1),at+Vector2(26,-1),at+Vector2(0,32)]),color)
    elif key in ["magnet","sage_focus","crit"]:
        _seal(at,35,color)
    else:
        draw_circle(at,30,Color("3796ac"))
        for i in range(4):
            draw_arc(at,12+i*5,age*0.5+i,age*0.5+i+PI*1.6,32,Color("9decdf"),2.0,true)
        draw_circle(at+Vector2(-9,-9),6,Color("ddfff1"))

func _card_index(key: String) -> int:
    for i in range(g.selected_cards.size()):
        if g.selected_cards[i].stat==key: return i
    return 0

func _pause() -> void:
    draw_rect(Rect2(0,0,1280,720),Color(0.06,0.10,0.11,0.88))
    _seal(Vector2(640,222),47,GOLD)
    _center("Chwila oddechu",640,324,37,CREAM,title)
    _center("Misja wstrzymana. Twoje zwoje czekają.",640,359,16,MUTED)
    _button(Rect2(467,400,346,56),"WRÓĆ DO WALKI    [ ESC ]")
    _button(Rect2(467,476,346,42),"DŹWIĘK: " + ("WYŁ." if g.muted else "WŁ."),false)
    _center("WASD  RUCH     SHIFT  KAWARIMI     X  KLONY",640,582,12,MUTED,mono)
    _center("SPACJA  TEMPO     F  EFEKTY     G  NIEŚMIERTELNOŚĆ",640,611,11,MUTED,mono)

func _result() -> void:
    draw_rect(Rect2(0,0,1280,720),Color(0.06,0.10,0.11,0.93))
    _box(Rect2(377,93,526,537),PAPER,Color("a18b61"),3)
    for y in [84.0,630.0]:
        _box(Rect2(355,y,570,22),Color("664b34"),GOLD,6)
        _box(Rect2(355,y-3,24,28),GOLD,Color.TRANSPARENT,4)
        _box(Rect2(901,y-3,24,28),GOLD,Color.TRANSPARENT,4)
    _center("RAPORT Z MISJI",640,145,12,Color("806840"),mono)
    _center("Misja wykonana" if victory else "Następnym razem…",640,199,30,INK,title)
    _center("SASORI POKONANY" if victory else "NINJA NIGDY SIĘ NIE PODDAJE",640,234,12,RED,mono)
    _line(269,426,428,Color("c3ac7f"))
    var rows := [["CZAS MISJI","%02d:%02d" % [int(g.clock/60),int(g.clock)%60]],["POKONANI NINJA",str(g.stat_kills)],["ZEBRANA CHAKRA",str(g.stat_exp_collected)],["ZNALEZIONE ZWOJE",str(g.scroll_count)],["POZIOM KOŃCOWY",str(g.level)]]
    for i in range(rows.size()):
        _text(rows[i][0],Vector2(430,312+i*40),12,Color("796748"),mono)
        _text(rows[i][1],Vector2(769,312+i*40),19,INK,mono)
    _button(Rect2(467,551,346,56),"JESZCZE JEDNA MISJA    ↵")
