extends Node2D
## NEW Godot gameplay architecture, not a port of the abandoned Go/Win32 code.
## MUGEN frames are loaded from imported community packs; temporary debug markers
## are visible only while a pack has not yet been supplied.

const MugenActor = preload("res://scripts/mugen_actor.gd")
const ShinobiUI = preload("res://scripts/shinobi_ui.gd")
const VIEW := Vector2(1280.0, 720.0)
const TILE_SIZE := 64
const MAX_ENEMIES := 110
const MAX_SHOTS := 90
const MAX_DROPS := 190
const MAX_FX := 110
const TRANSFORM_SAGE := 120.0
const TRANSFORM_KCM := 330.0
const BOSS_TIME := 480.0
const BOSS_HP := 15000.0
const PLAYER_SPEED := 152.0
const PLAYER_MAX_HP := 125.0
const TRANSFORM_DAMAGE_BOOST := [1.0, 1.58, 2.22]
const TRANSFORM_RATE_BOOST := [1.0, 0.82, 0.67]
const TRANSFORM_SHOT_SCALE := [1.0, 1.16, 1.32]
const ENEMY_PACKS := ["sound_scythe", "sound_pole", "sound_mirror", "sound_heavy"]
const QUALITY_LABELS := ["LOW FX", "NORMAL FX"]
const JUTSU := {
    "rasengan":{"name":"RASENGAN","desc":"Odblokuj kulę chakry, która wspiera podstawowe kunai.","tier":1,"max":1},
    "kunai_twin":{"name":"PODWÓJNE KUNAI","desc":"Rzucaj dodatkowym kunai w każdej salwie.","tier":0,"max":3},
    "kunai_rapid":{"name":"SZYBKIE RZUTY","desc":"Skróć przerwę między kolejnymi salwami kunai.","tier":0,"max":4},
    "kunai_pierce":{"name":"PRZEBIJAJĄCE KUNAI","desc":"Każde kunai przebija kolejnego przeciwnika.","tier":1,"max":3},
    "kunai_explosive":{"name":"WYBUCHOWA PIECZĘĆ","desc":"Co kilka rzutów kunai wybucha przy trafieniu.","tier":1,"max":2},
    "naruto_rendan":{"name":"NARUTO RENDAN","desc":"Klony pod X wykonują serię ciosów. Siła rośnie z Kage Bunshin.","tier":2,"max":3},
    "oiroke":{"name":"OIROKE NO JUTSU","desc":"Automatyczna bariera rani i zatrzymuje pobliskich ninja.","tier":2,"max":3},
    "oodama":{"name":"ŌDAMA RASENGAN","desc":"Większa kula chakry zadaje wyższe obrażenia.","tier":1,"max":3},
    "rasenshuriken":{"name":"RASENSHURIKEN","desc":"Dodaj wybuchowe shurikeny do salw Rasengana.","tier":2,"max":2},
    "rasenrendan":{"name":"RASENRENDAN","desc":"Wystrzel serię dodatkowych Rasenganów.","tier":1,"max":3},
    "rasenornado":{"name":"RASENORNADO","desc":"Tornada chakry ścigają i ranią grupy przeciwników.","tier":2,"max":2},
    "chakra_flow":{"name":"PRZEPŁYW CHAKRY","desc":"Skróć przerwę między seriami Rasengana.","tier":0,"max":5},
    "clones":{"name":"KAGE BUNSHIN","desc":"Więcej klonów, dłuższy czas działania i silniejszy Rendan.","tier":1,"max":4},
    "speed":{"name":"SHUNSHIN","desc":"Poruszaj się szybciej i częściej używaj Kawarimi.","tier":0,"max":5},
    "magnet":{"name":"WYCZUCIE CHAKRY","desc":"Przyciągaj kule chakry i zwoje z większej odległości.","tier":0,"max":5},
    "max_hp":{"name":"WITALNOŚĆ UZUMAKI","desc":"Zwiększ maksymalne HP i natychmiast odzyskaj zdrowie.","tier":0,"max":5},
    "pierce":{"name":"PENETRACJA CHAKRY","desc":"Rasengany przenikają przez kolejnych przeciwników.","tier":1,"max":3},
    "multishot":{"name":"PODWÓJNY RASENGAN","desc":"Dodaj kolejną kulę chakry do każdego wachlarza.","tier":1,"max":3},
    "regeneration":{"name":"MEDYTACJA SENNINA","desc":"Odzyskuj HP po pokonaniu kolejnej grupy ninja.","tier":1,"max":3},
    "crit":{"name":"OSTRZE WIATRU","desc":"Zwiększ szansę na trafienie krytyczne.","tier":1,"max":4},
    "sage_focus":{"name":"MOC NATURY","desc":"Zwiększ zasięg Rasenshurikena i tornad chakry.","tier":3,"max":1}
}
const RARITY_NAMES := ["COMMON","RARE","EPIC","LEGENDARY"]
const RARITY_COLORS := [Color("dee4d7"),Color("70c8ff"),Color("d29dff"),Color("ffe287")]


var ui_view
var visual_delta := 0.0166667
var rng := RandomNumberGenerator.new()
var clock := 0.0
var speed_index := 0
# Former 2x is now NORMAL, with two optional acceleration settings.
var speeds := [2.0,3.0,4.0]
var speed_labels := ["NORMAL","FAST","TURBO"]
var playing := false
var paused := false
var finished := false
var muted := false
var low_fx := false
var godmode := false
var transform_pause := 0.0
var transform_total := 0.0
var transform_target_form := -1
var transform_stage := 0
var burst_frames: Array[Texture2D] = []
var godmode_button: Button
var godmode_hud_button: Button
var result_body: Label
var upgrade_footer: Label
var upgrade_sub: Label
var transform_overlay: ColorRect
var special_sfx_player: AudioStreamPlayer
var result_meta: Label
var hostile_orb_clock := 0.0
var stat_kills := 0
var stat_exp_collected := 0
var player
var player_hp := PLAYER_MAX_HP
var player_pos := Vector2.ZERO
var player_form := 0
var player_facing := 1.0
var player_vel := Vector2.ZERO
var dash_timer := 0.0
var dash_cooldown := 0.0
var invulnerable := 0.0
var attack_timer := 0.0
var rasengan_timer := 0.0
var kunai_sequence := 0
var oiroke_cd := 10.0
var oiroke_time := 0.0
var oiroke_hits: Dictionary = {}
var oiroke_pos := Vector2.ZERO
var kawarimi_fx: Array[Dictionary] = []
var stage_ground: Texture2D
var item_art: Dictionary = {}
var naruto_effects: Array[Texture2D] = []
var naruto_combo_frames: Array[Texture2D] = []
var kawarimi_log: Texture2D
var clone_timer := 0.0
var clone_cooldown := 0.0
var clones: Array[Dictionary] = []
var enemies: Array[Dictionary] = []
var shots: Array[Dictionary] = []
var drops: Array[Dictionary] = []
var fx: Array[Dictionary] = []
var upgrades: Dictionary = {}
var burst_remaining := 0
var burst_timer := 0.0
var rasenshuriken_counter := 0
var tornado_timer := 0.0
var tornadoes: Array[Dictionary] = []
var recovery_kills := 0
var level := 1
var exp_value := 0.0
var exp_needed := 18.0
var spawn_timer := 0.0
var boss: Dictionary = {}
var boss_active := false
var boss_vfx: Dictionary = {}
var boss_telegraphs: Array[Dictionary] = []
var boss_phase_reached := 0
var boss_attack_history: Array[String] = []
var boss_label: Label
var event_banner: Label
var selected_cards: Array[Dictionary] = []
var picking := false
var scroll_count := 0
var title_controls: Control
var ui: CanvasLayer
var hud: Label
var hud_info: Label
var boss_bar: ProgressBar
var panel: PanelContainer
var upgrade_overlay: ColorRect
var card_art: Array[TextureRect] = []
var card_titles: Array[Label] = []
var card_descriptions: Array[Label] = []
var card_rarities: Array[Label] = []
var card_levels: Array[Label] = []
var result_text: Label
var card_buttons: Array[Button] = []
var quality_button: Button
var music_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var rasengan_frames: Array[Texture2D] = []
var shuriken_frames: Array[Texture2D] = []
var tornado_frames: Array[Texture2D] = []
var tiles: Array[Texture2D] = []
var prop_textures: Array[Texture2D] = []
var hud_scroll_texture: Texture2D
var boss_banner_texture: Texture2D
var title_font: Font
var body_font: Font
var hud_back: TextureRect
var camera: Camera2D
var quicksand_zones: Array[Dictionary] = []
var hazard_timer := 0.0
var miniboss_timer := 0.0
var event_msg := ""
var event_time := 0.0
var log: FileAccess

func _read_png(asset_path:String) -> Texture2D:
    if not FileAccess.file_exists(asset_path):
        return null
    var raw := FileAccess.get_file_as_bytes(asset_path)
    var img := Image.new()
    if img.load_png_from_buffer(raw) != OK:
        return null
    return ImageTexture.create_from_image(img)

func _ready() -> void:
    rng.randomize()
    texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    _log_boot()
    for i in range(6):
        var path := "res://assets/world/ground_%02d.png" % i
        var tex := _read_png(path)
        if tex != null:
            tiles.append(tex)
    for i in range(4):
        var p := "res://assets/world/prop_%02d.png" % i
        var tex := _read_png(p)
        if tex != null:
            prop_textures.append(tex)
    for i in range(12):
        var path := "res://assets/vfx/rasengan_%02d.png" % i
        var tex := _read_png(path)
        if tex != null:
            rasengan_frames.append(tex)
    for i in range(12):
        var p_s := "res://assets/vfx/rasenshuriken_%02d.png" % i
        var p_t := "res://assets/vfx/rasenornado_%02d.png" % i
        var p_b := "res://assets/vfx/burst_%02d.png" % i
        var tex_s := _read_png(p_s)
        var tex_t := _read_png(p_t)
        var tex_b := _read_png(p_b)
        if tex_s != null: shuriken_frames.append(tex_s)
        if tex_t != null: tornado_frames.append(tex_t)
        if tex_b != null: burst_frames.append(tex_b)
    for fx_name in ["senbon","chakra","sand","blast","poison","smoke","hit","slash","meteor"]:
        var frames: Array[Texture2D] = []
        for j in range(18):
            var effect_path := "res://assets/boss_sasori/%s_%02d.png" % [fx_name,j]
            var boss_tex := _read_png(effect_path)
            if boss_tex != null:
                frames.append(boss_tex)
        boss_vfx[fx_name] = frames
    hud_scroll_texture = _read_png("res://assets/ui/hud_scroll.png")
    boss_banner_texture = _read_png("res://assets/ui/boss_banner.png")
    title_font = SystemFont.new()
    (title_font as SystemFont).font_names = PackedStringArray(["Georgia", "Palatino Linotype", "Garamond"])
    body_font = SystemFont.new()
    (body_font as SystemFont).font_names = PackedStringArray(["Georgia", "Cambria", "Times New Roman"])
    stage_ground = _read_png("res://assets/stage_desert/desert_ground_1024.png")
    prop_textures.clear()
    for i in range(12):
        var prop := _read_png("res://assets/stage_desert/prop_%02d.png" % i)
        if prop != null: prop_textures.append(prop)
    for kind in ["kunai", "shuriken", "projectile_dart", "chakra_bomb", "explosive_note", "metal_needle", "small_shuriken"]:
        item_art[kind] = _read_png("res://assets/vfx_items/%s.png" % kind)
    kawarimi_log = _read_png("res://assets/stage_desert/kawarimi_log.png")
    camera = Camera2D.new()
    camera.zoom = Vector2(1.5,1.5)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 10.0
    add_child(camera)
    camera.make_current()
    player = MugenActor.new()
    player.pack_name = "naruto_base"
    player.fallback_color = Color("ea8429")
    add_child(player)
    music_player = AudioStreamPlayer.new()
    add_child(music_player)
    sfx_player = AudioStreamPlayer.new()
    add_child(sfx_player)
    special_sfx_player = AudioStreamPlayer.new()
    add_child(special_sfx_player)
    if FileAccess.file_exists("res://assets/audio/forest_music.mp3"):
        music_player.stream = AudioStreamMP3.load_from_buffer(FileAccess.get_file_as_bytes("res://assets/audio/forest_music.mp3"))
        music_player.volume_db = -10.0
        if music_player.stream is AudioStreamMP3:
            (music_player.stream as AudioStreamMP3).loop = true
    ui = CanvasLayer.new()
    add_child(ui)
    _make_ui()
    _show_title()
    _log("boot: loaded %d tiles / %d rasengan frames" % [tiles.size(),rasengan_frames.size()])

func _log_boot() -> void:
    var path := "user://startup.log"
    log = FileAccess.open(path,FileAccess.WRITE)
    _log("Boot Godot %s | OS=%s" % [Engine.get_version_info().get("string","unknown"),OS.get_name()])

func _log(txt:String) -> void:
    print("[SHINOBI] ",txt)
    if log != null:
        log.store_line("[%.3f] %s" % [Time.get_ticks_msec()/1000.0,txt])
        log.flush()

func _make_label(parent:Node, text_value:String, size:int, color:Color) -> Label:
    var label := Label.new()
    label.text = text_value
    label.add_theme_font_size_override("font_size",size)
    if body_font != null:
        label.add_theme_font_override("font", body_font)
    label.add_theme_color_override("font_color",color)
    parent.add_child(label)
    return label

func _scroll_label(parent: Node, text_value: String, font_size: int, color: Color, rect: Rect2, centered: bool = true) -> Label:
    var label := Label.new()
    label.text = text_value
    label.position = rect.position
    label.size = rect.size
    label.add_theme_font_size_override("font_size",font_size)
    if body_font != null:
        label.add_theme_font_override("font", body_font)
    label.add_theme_color_override("font_color",color)
    label.add_theme_color_override("font_shadow_color",Color(0.05,0.03,0.01,0.07))
    label.add_theme_constant_override("shadow_offset_x",1)
    label.add_theme_constant_override("shadow_offset_y",1)
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(label)
    return label

func _make_ui() -> void:
    ui_view = ShinobiUI.new()
    ui_view.g = self
    ui.add_child(ui_view)

func _show_title() -> void:
    ui_view.queue_redraw()

func _start() -> void:
    _log("run started")
    clock=0.0
    speed_index=0
    playing=true
    paused=false
    picking=false
    finished=false
    player_hp=PLAYER_MAX_HP
    player_pos=Vector2.ZERO
    player_form=0
    player_facing=1.0
    dash_timer=0
    dash_cooldown=0
    invulnerable=0
    attack_timer=0
    rasengan_timer=2.6
    kunai_sequence=0
    oiroke_cd=12.0
    oiroke_time=0.0
    oiroke_hits.clear()
    kawarimi_fx.clear()
    clone_cooldown=0
    spawn_timer=0
    scroll_count=0
    event_time=0
    transform_pause=0.0
    transform_total=0.0
    transform_target_form=-1
    transform_stage=0
    boss_active=false
    if boss.has("actor") and is_instance_valid(boss["actor"]): boss["actor"].queue_free()
    boss={}
    boss_telegraphs.clear()
    boss_phase_reached = 0
    boss_attack_history.clear()
    quicksand_zones.clear()
    hazard_timer = 3.0
    miniboss_timer = 45.0
    level=1
    exp_value=0
    exp_needed=18
    upgrades.clear()
    for skill in JUTSU.keys(): upgrades[skill]=0
    burst_remaining=0
    burst_timer=0.0
    rasenshuriken_counter=0
    tornado_timer=0.0
    recovery_kills=0
    stat_kills=0
    stat_exp_collected=0
    tornadoes.clear()
    for e in enemies: e["actor"].queue_free()
    enemies.clear()
    for c in clones: c["actor"].queue_free()
    clones.clear()
    shots.clear()
    drops.clear()
    fx.clear()
    player.set_pack("naruto_base")
    if music_player.stream != null:
        music_player.volume_db = -80.0 if muted else -11.0
        music_player.play()
    queue_redraw()

func _input(event:InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode==KEY_ENTER and (not playing or finished):
            _start()
        elif event.keycode==KEY_ESCAPE and playing and not picking and not finished:
            paused=not paused
            _flash("PAUZA" if paused else "WALKA")
        elif event.keycode==KEY_SPACE and playing and not finished:
            speed_index=(speed_index+1)%3
            _flash("TEMPO: %s" % speed_labels[speed_index])
        elif event.keycode==KEY_X and playing and not picking and not paused and not finished:
            _spawn_clones()
        elif event.keycode==KEY_G:
            _toggle_godmode()
        elif event.keycode==KEY_F9 and playing and not boss_active and not finished and not picking:
            clock=BOSS_TIME
            # Dev test gets an approximately endgame build to verify all three phases.
            upgrades["rasengan"]=1
            upgrades["oodama"]=2
            upgrades["chakra_flow"]=2
            upgrades["multishot"]=1
            upgrades["kunai_twin"]=2
            upgrades["clones"]=2
            upgrades["naruto_rendan"]=2
            upgrades["oiroke"]=1
            if player_form<2:
                _complete_transform(2)
            _spawn_boss()
        elif event.keycode==KEY_M:
            muted=not muted
            music_player.volume_db=-80.0 if muted else -10.0
            sfx_player.volume_db=-80.0 if muted else -6.0
            special_sfx_player.volume_db=-80.0 if muted else -5.0
        elif event.keycode==KEY_F:
            _toggle_fx()
        elif picking and event.keycode in [KEY_1,KEY_2,KEY_3]:
            _choose_card(event.keycode-KEY_1)

func _toggle_fx() -> void:
    low_fx=not low_fx

func _toggle_godmode() -> void:
    godmode = not godmode
    if godmode: player_hp = PLAYER_MAX_HP + float(upgrades.get("max_hp",0))*18.0
    _flash("NIEŚMIERTELNOŚĆ WŁĄCZONA" if godmode else "NIEŚMIERTELNOŚĆ WYŁĄCZONA",1.3)

func _process(delta:float) -> void:
    visual_delta = minf(delta,0.06)
    if not playing or finished:
        return
    hostile_orb_clock += delta
    if transform_pause > 0.0:
        transform_pause = maxf(0.0, transform_pause - delta)
        if player != null:
            player.tick(delta * 0.7)
        _update_fx(delta)
        _update_hud()
        camera.position = player_pos
        queue_redraw()
        if transform_pause <= 0.0 and transform_target_form >= 0:
            _complete_transform(transform_target_form)
        return
    if paused or picking:
        queue_redraw()
        return
    var dt:float=minf(delta,0.06)*speeds[speed_index]
    clock+=dt
    _update_player(dt)
    if player_form==0 and clock>=TRANSFORM_SAGE:
        _transform(1)
    if player_form==1 and clock>=TRANSFORM_KCM:
        _transform(2)
    if not boss_active and clock>=BOSS_TIME:
        _spawn_boss()
    _update_spawns(dt)
    _update_clones(dt)
    _update_enemies(dt)
    _update_boss_telegraphs(dt)
    _update_projectiles(dt)
    _update_tornadoes(dt)
    _update_oiroke(dt)
    _update_hazards(dt)
    _update_drops(dt)
    _update_fx(dt)
    _update_hud()
    camera.position=player_pos
    queue_redraw()
    if player_hp<=0:
        _finish(false)

func _update_player(dt:float) -> void:
    var vel=Vector2.ZERO
    if Input.is_physical_key_pressed(KEY_A): vel.x-=1
    if Input.is_physical_key_pressed(KEY_D): vel.x+=1
    if Input.is_physical_key_pressed(KEY_W): vel.y-=1
    if Input.is_physical_key_pressed(KEY_S): vel.y+=1
    vel=vel.normalized()
    dash_timer=maxf(0.0,dash_timer-dt)
    dash_cooldown=maxf(0.0,dash_cooldown-dt)
    invulnerable=maxf(0.0,invulnerable-dt)
    if Input.is_key_pressed(KEY_SHIFT) and dash_cooldown<=0 and vel.length()>0:
        dash_timer=0.22
        dash_cooldown=maxf(1.7,3.2-float(upgrades["speed"])*0.22)
        invulnerable=0.46
        kawarimi_fx.append({"pos":player_pos,"life":0.68,"max":0.68})
        _sfx("dash.wav")
    var mul=3.7 if dash_timer>0 else 1.0
    var hazard_mul := 1.0
    for q in quicksand_zones:
        if player_pos.distance_to(q["pos"]) < float(q["radius"]):
            hazard_mul = minf(hazard_mul, 0.38)
    player_vel=vel* (PLAYER_SPEED+float(upgrades["speed"])*7.0 + player_form*5.0)*mul*hazard_mul
    player_pos+=player_vel*dt
    player.position=player_pos
    if vel.x!=0: player_facing=signf(vel.x)
    player.facing=player_facing
    player.moving=vel.length_squared()>0
    player.dashing = dash_timer > 0.0
    player.tick(visual_delta)
    clone_cooldown=maxf(0.0,clone_cooldown-dt)
    attack_timer-=dt
    if attack_timer<=0:
        _fire_kunai()
        attack_timer=maxf(0.16,0.71-float(upgrades["kunai_rapid"])*0.09)*TRANSFORM_RATE_BOOST[player_form]
    rasengan_timer-=dt
    if int(upgrades["rasengan"])>0:
        if burst_remaining>0:
            burst_timer-=dt
            if burst_timer<=0:
                _fire_rasengan(true)
                burst_remaining-=1
                burst_timer=0.13
        if rasengan_timer<=0:
            _fire_rasengan(false)
            if int(upgrades["rasenrendan"])>0:
                burst_remaining=int(upgrades["rasenrendan"])*2
                burst_timer=0.12
            rasengan_timer=maxf(1.4,3.5-float(upgrades["chakra_flow"])*0.30)*TRANSFORM_RATE_BOOST[player_form]
    tornado_timer-=dt
    if int(upgrades["rasenornado"])>0 and tornado_timer<=0:
        _summon_tornadoes()
        tornado_timer=maxf(4.1,9.5-float(upgrades["rasenornado"])*1.7)

func _transform(form:int) -> void:
    if transform_pause > 0.0:
        return
    transform_target_form = form
    transform_total = 1.05
    transform_pause = transform_total
    transform_stage = form
    invulnerable = 2.5
    player.attack = true
    player.moving = false
    if player.actions.has("100"):
        player.set_action("100")
    _flash("SAGE MODE  /  SENNIN MODE" if form==1 else "KYUBI CHAKRA MODE",3.0)
    _sfx("transform.mp3")
    _log("transformation begin %d at %.2f" % [form,clock])

func _complete_transform(form:int) -> void:
    player_form=form
    player.set_pack("naruto_sage" if form==1 else "naruto_kcm")
    player.attack = false
    invulnerable=2.1
    player_hp=minf(PLAYER_MAX_HP+float(upgrades["max_hp"])*18.0,player_hp+34.0+8.0*form)
    player.form_tint=Color(1.0,0.92,0.96) if form==1 else Color(1.0,0.96,0.85) if form==2 else Color.WHITE
    if fx.size()<MAX_FX:
        fx.append({"pos":player_pos,"life":0.72,"max":0.72,"radius":150.0 + 20.0*form,"kind":"pulse"})
    transform_target_form = -1
    transform_stage = 0
    _log("transformation end %d at %.2f" % [form,clock])

func _flash(txt:String,duration:float=2.0) -> void:
    event_msg=txt
    event_time=duration

func _enemy_actor(pack:String,at:Vector2,tint:Color):
    var actor:=MugenActor.new()
    actor.pack_name=pack
    actor.fallback_color=tint
    actor.position=at
    add_child(actor)
    return actor

func _update_spawns(dt:float) -> void:
    spawn_timer-=dt
    miniboss_timer-=dt
    if boss_active:
        return
    if enemies.size()<MAX_ENEMIES and spawn_timer<=0:
        var pressure=minf(1.0,clock/480.0)
        var n=1 + int(pressure*4.0)
        for i in range(n):
            _spawn_enemy(false)
        spawn_timer=lerpf(2.0,1.02,pressure)
    if clock > 75.0 and miniboss_timer <= 0.0:
        _spawn_enemy(true)
        miniboss_timer = 54.0

func _spawn_enemy(elite:bool) -> void:
    if enemies.size()>=MAX_ENEMIES: return
    var theta=rng.randf_range(0.0,TAU)
    var at=player_pos+Vector2.from_angle(theta)*rng.randf_range(490.0,655.0)
    var kinds=["sound_scythe","sound_pole","sound_mirror","sound_heavy"]
    var kind:String="sound_heavy" if elite else kinds[rng.randi_range(0,kinds.size()-1)]
    var ranged=kind=="sound_mirror" or kind=="sound_pole" or elite
    var hp_table={"sound_scythe":74.0,"sound_pole":115.0,"sound_mirror":91.0,"sound_heavy":205.0}
    var speed_table={"sound_scythe":109.0,"sound_pole":65.0,"sound_mirror":53.0,"sound_heavy":39.0}
    var maxhp=float(hp_table[kind])*(1.0+clock/700.0)
    if elite: maxhp*=5.2
    var actor=_enemy_actor(kind,at,Color("d0bd95"))
    if elite: actor.sprite_scale*=1.48
    enemies.append({"pos":at,"hp":maxhp,"max_hp":maxhp,"actor":actor,"ranged":ranged,
        "kind":kind,"speed":float(speed_table[kind]),"hit_cd":0.0,"missile_cd":rng.randf_range(1.3,3.0),
        "elite":elite,"stagger":0.0})
    if elite: _flash("ELITE  /  SOUND NINJA",1.3)

func _estimated_dps() -> float:
    var amount := 1.0 + float(upgrades.get("multishot",0))*0.75
    var damage := 37.0 * (1.0 + float(upgrades.get("oodama",0))*0.22) * TRANSFORM_DAMAGE_BOOST[2]
    var delay := maxf(1.4,3.5 - float(upgrades.get("chakra_flow",0))*0.30)*TRANSFORM_RATE_BOOST[2]
    var rendan := 1.0 + float(upgrades.get("rasenrendan",0))*0.16
    var clone_damage := float(upgrades.get("clones",0))*8.0
    var aoe_damage := float(upgrades.get("rasenshuriken",0))*19.0 + float(upgrades.get("rasenornado",0))*18.0
    # Approximate useful contact DPS, not theoretical point-blank maximum.
    var kunai_dps := (1.0 + float(upgrades.get("kunai_twin",0)))*(12.5*TRANSFORM_DAMAGE_BOOST[2])/maxf(0.18,0.71-float(upgrades.get("kunai_rapid",0))*0.09)*0.42
    return kunai_dps + (amount * damage / delay * rendan * 0.52 if upgrades.get("rasengan",0)>0 else 0.0) + clone_damage + aoe_damage

func _spawn_boss() -> void:
    boss_active=true
    for e in enemies:
        e["actor"].queue_free()
    enemies.clear()
    boss_telegraphs.clear()
    # Previous ranged shots are removed at the arena transition.
    for sh in shots.duplicate():
        if sh.get("hostile",false): shots.erase(sh)
    var at=player_pos+Vector2(360,-180)
    var actor = _enemy_actor("sasori",at,Color("bd253f"))
    actor.sprite_scale = maxf(actor.sprite_scale,1.62)
    var dynamic_hp := clampf(_estimated_dps()*85.0,4800.0,76000.0)
    boss={"pos":at,"hp":dynamic_hp,"max_hp":dynamic_hp,"actor":actor,
          "attack_cd":1.8,"phase":1,"wave_cd":4.0,"attack_index":0,"phase_pause":0.7}
    boss_phase_reached=1
    _flash("AKATSUKI: SASORI  /  THE RED SAND",4.3)
    _sfx("boss.wav")
    _log("Sasori spawned at %.1f: HP %.0f / estimated DPS %.0f" % [clock,dynamic_hp,_estimated_dps()])

func _closest_target(at:Vector2,max_distance:float)->Dictionary:
    var best:Dictionary={}
    var dist=max_distance*max_distance
    for e in enemies:
        var d=at.distance_squared_to(e["pos"])
        if d<dist:
            dist=d
            best=e
    if boss_active:
        var d=at.distance_squared_to(boss["pos"])
        if d<dist: best=boss
    return best

func _fire_kunai() -> void:
    if shots.size()>MAX_SHOTS-12: return
    var target := _closest_target(player_pos,670.0)
    if target.is_empty(): return
    var aim:Vector2=(target["pos"]-player_pos).normalized()
    kunai_sequence+=1
    var count := mini(5,1+int(upgrades["kunai_twin"])+(1 if player_form==2 and kunai_sequence%3==0 else 0))
    var explosive := int(upgrades["kunai_explosive"])>0 and kunai_sequence%maxi(3,7-int(upgrades["kunai_explosive"])*2)==0
    var tint := Color.WHITE if player_form==0 else Color(1.0,0.4,0.42) if player_form==1 else Color(1.0,0.7,0.23)
    for i in range(count):
        var heading := aim.rotated((float(i)-float(count-1)*0.5)*0.16)
        shots.append({"pos":player_pos+Vector2(0,-23),"dir":heading,"life":1.6,
            "damage":(12.5+float(upgrades["kunai_explosive"])*1.5)*TRANSFORM_DAMAGE_BOOST[player_form],
            "size":1.0,"kind":"kunai_explosive" if explosive and i==0 else "kunai",
            "tint":tint,"pierced":0,"hit":{},"velocity":495.0})

func _fire_rasengan(rapid:bool=false) -> void:
    if shots.size()>MAX_SHOTS-12: return
    var target=_closest_target(player_pos,670.0)
    if target.is_empty():return
    var base_dir:Vector2=(target["pos"]-player_pos).normalized()
    var amount=1+int(upgrades["multishot"])
    if player_form==2 and upgrades["multishot"] < 3:
        amount += 1
    rasenshuriken_counter+=1 if not rapid else 0
    var shuriken_on=not rapid and int(upgrades["rasenshuriken"])>0 and rasenshuriken_counter%maxi(3,7-int(upgrades["rasenshuriken"])*2)==0
    for i in range(amount):
        var rot=(float(i)-float(amount-1)/2.0)*0.20
        var angle=base_dir.rotated(rot)
        var big=(1.0+float(upgrades["oodama"])*0.26)*TRANSFORM_SHOT_SCALE[player_form]
        var kind="shuriken" if shuriken_on and i==0 else "rasengan"
        var chance=0.04+0.055*float(upgrades["crit"])
        var critical=rng.randf()<chance
        var damage=37.0*(1.0+float(upgrades["oodama"])*0.22)*TRANSFORM_DAMAGE_BOOST[player_form]
        if kind=="shuriken":damage*=1.55
        if rapid:damage*=0.63
        if critical:damage*=1.8
        var shot_tint := Color.WHITE if player_form==0 else Color(1.0,0.44,0.38,1.0) if player_form==1 else Color(1.0,0.67,0.21,1.0)
        shots.append({"pos":player_pos+Vector2(0,-28),"dir":angle,
            "life":1.32,"damage":damage,"size":big*(1.18 if kind=="shuriken" else 1.0),
            "kind":kind,"critical":critical,"pierced":0,"hit":{},"tint":shot_tint})
    _sfx("rasengan.wav")

func _aoe_damage(at:Vector2, radius:float, damage:float) -> void:
    for e in enemies.duplicate():
        if enemies.has(e) and at.distance_squared_to(e["pos"])<=radius*radius:
            _damage_target(e,damage)
    if boss_active and boss.get("hp",0.0)>0.0 and at.distance_squared_to(boss["pos"])<=radius*radius:
        _damage_target(boss,damage)

func _projectile_impact(shot:Dictionary,at:Vector2) -> void:
    if shot.get("kind","")=="kunai_explosive":
        var blast_radius=45.0+float(upgrades["kunai_explosive"])*15.0
        _aoe_damage(at,blast_radius,float(shot["damage"])*0.68)
        if fx.size()<MAX_FX: fx.append({"pos":at,"life":0.36,"max":0.36,"radius":blast_radius,"kind":"aoe"})
    if shot.get("kind","")=="shuriken":
        var radius=85.0+float(upgrades["rasenshuriken"])*36.0+(37.0 if int(upgrades["sage_focus"])>0 else 0.0)
        _aoe_damage(at,radius,float(shot["damage"])*0.82)
        if fx.size()<MAX_FX:
            fx.append({"pos":at,"life":0.48,"max":0.48,"radius":radius,"kind":"aoe"})
    elif int(upgrades["oodama"])>0 and fx.size()<MAX_FX:
        fx.append({"pos":at,"life":0.22,"max":0.22,"radius":23.0+int(upgrades["oodama"])*12.0,"kind":"impact"})
    if shot.get("critical",false) and fx.size()<MAX_FX:
        fx.append({"pos":at,"life":0.35,"max":0.35,"radius":29.0,"kind":"critical"})

func _summon_tornadoes() -> void:
    for i in range(mini(4,int(upgrades["rasenornado"]))):
        var angle=float(i)*TAU/maxi(1,int(upgrades["rasenornado"]))
        var at=player_pos+Vector2.from_angle(angle)*70.0
        tornadoes.append({"pos":at,"life":4.4,"tick":0.03,"orbit":angle})
    _flash("FUUTON: RASENORNADO",1.3)
    _sfx("transform.wav")

func _update_tornadoes(dt:float) -> void:
    for t in tornadoes.duplicate():
        t["life"]-=dt
        if float(t["life"])<=0.0:
            tornadoes.erase(t)
            continue
        var pos:Vector2=t["pos"]
        var target=_closest_target(pos,510.0)
        if not target.is_empty():
            pos+=(target["pos"]-pos).normalized()*122.0*dt
        else:
            t["orbit"]+=dt*1.8
            var at=player_pos+Vector2.from_angle(t["orbit"])*105.0
            pos=pos.move_toward(at,130.0*dt)
        t["pos"]=pos
        for e in enemies:
            if pos.distance_squared_to(e["pos"])<80.0*80.0:
                e["pos"]+=(pos-e["pos"]).normalized()*dt*25.0
        t["tick"]-=dt
        if t["tick"]<=0:
            var radius=61.0+(22.0 if int(upgrades["sage_focus"])>0 else 0.0)
            _aoe_damage(pos,radius,13.0+float(upgrades["rasenornado"])*8.0)
            t["tick"]=0.29

func _damage_target(target:Dictionary,damage:float) -> void:
    if target.has("actor"): target["actor"].hit_flash = 0.13
    if target.is_empty() or not target.has("hp"):return
    if target==boss and boss.get("phase_pause",0.0) > 0.0:
        return
    if target==boss:
        var active_phase := int(boss.get("phase", 1))
        var threshold := float(boss["max_hp"]) * (0.66 if active_phase==1 else 0.33 if active_phase==2 else 0.0)
        target["hp"] = maxf(threshold - 0.01, float(target["hp"]) - damage) if active_phase < 3 else float(target["hp"]) - damage
    else:
        target["hp"]-=damage
    var at:Vector2=target["pos"]
    if fx.size()<MAX_FX and not low_fx:
        fx.append({"pos":at,"life":0.23,"max":0.23,"kind":"impact"})
    if target["hp"]<=0:
        if target==boss:
            boss["hp"]=0.0
            _finish(true)
        else:
            _kill_enemy(target)

func _kill_enemy(e:Dictionary) -> void:
    if not enemies.has(e):return
    var at:Vector2=e["pos"]
    var elite:bool=e["elite"]
    e["actor"].queue_free()
    enemies.erase(e)
    recovery_kills+=1
    stat_kills += 1
    if int(upgrades["regeneration"])>0 and recovery_kills>=20-int(upgrades["regeneration"])*4:
        recovery_kills=0
        player_hp=minf(PLAYER_MAX_HP+float(upgrades["max_hp"])*18.0,player_hp+8.0+float(upgrades["regeneration"])*5.0)
        if fx.size()<MAX_FX: fx.append({"pos":player_pos,"life":0.6,"max":0.6,"radius":38.0,"kind":"heal"})
    if drops.size()<MAX_DROPS:
        drops.append({"pos":at,"type":"xp","value":3.0+(1 if elite else 0)*9})
        if rng.randf()<0.005:
            drops.append({"pos":at+Vector2(11,0),"type":"heal","value":20.0})
        if elite or rng.randf()<0.014:
            drops.append({"pos":at+Vector2(0,-10),"type":"scroll","value":1.0})

func _update_enemies(dt:float) -> void:
    for e in enemies.duplicate():
        var at:Vector2=e["pos"]
        if at.distance_squared_to(player_pos)>1450.0*1450.0:
            e["actor"].queue_free()
            enemies.erase(e)
            continue
        var target=player_pos
        for c in clones:
            if c["pos"].distance_squared_to(at)<target.distance_squared_to(at):
                target=c["pos"]
        var direction:Vector2=(target-at).normalized()
        var kind:String=e["kind"]
        var distance=at.distance_to(target)
        var separation=165.0 if kind=="sound_mirror" else 100.0 if kind=="sound_pole" else 0.0
        e["stagger"]=maxf(0.0,e["stagger"]-dt)
        if distance>separation and float(e["stagger"])<=0:
            at+=direction*float(e["speed"])*dt
        e["pos"]=at
        e["actor"].position=at
        e["actor"].moving=distance>separation and float(e["stagger"])<=0
        e["actor"].attack=false
        if absf(direction.x)>0.07: e["actor"].facing=signf(direction.x)
        e["actor"].tick(visual_delta)
        e["hit_cd"]=maxf(0.0,e["hit_cd"]-dt)
        if at.distance_squared_to(player_pos)<1300 and e["hit_cd"]<=0 and invulnerable<=0 and not godmode:
            player_hp-=11.0 if kind=="sound_heavy" else 8.0
            invulnerable=0.55
            e["hit_cd"]=1.2
            _sfx("impact.wav")
        for c in clones.duplicate():
            if at.distance_squared_to(c["pos"])<760:
                c["hp"]-=13.0*dt
        e["missile_cd"]-=dt
        if e["missile_cd"]<=0 and distance<600 and shots.size()<MAX_SHOTS-14:
            e["actor"].pose_action="200"
            e["actor"].pose_time=0.45
            if kind=="sound_mirror":
                for offs in [-0.15,0.0,0.15]:
                    _enemy_shot(at,direction.rotated(offs),"small_shuriken",9.0,262.0,2.6)
                e["missile_cd"]=4.3
            elif kind=="sound_pole":
                for offs in [-0.27,0.0,0.27]:
                    _enemy_shot(at,direction.rotated(offs),"projectile_dart",10.0,320.0,1.65)
                e["missile_cd"]=4.0
            elif kind=="sound_heavy":
                for i in range(8 if e["elite"] else 5):
                    _enemy_shot(at,Vector2.from_angle(float(i)*TAU/(8 if e["elite"] else 5)),"chakra_bomb",14.0,172.0,2.9)
                e["missile_cd"]=5.1
            else:
                at=at.move_toward(target,44.0)
                e["pos"]=at
                e["actor"].position=at
                _enemy_shot(at,direction,"shuriken",10.5,360.0,1.0)
                e["missile_cd"]=3.5
    if boss_active and boss["hp"]>0:
        _update_boss(dt)

func _enemy_shot(at:Vector2, direction:Vector2, art:String, damage:float, velocity:float, ttl:float)->void:
    shots.append({"pos":at+Vector2(0,-20),"dir":direction.normalized(),"life":ttl,"damage":damage,
        "size":0.8,"hostile":true,"item_vfx":art,"velocity":velocity,"hit":{}})

func _boss_shot(origin:Vector2, heading:Vector2, art:String, size:float, damage:float, speed:float, ttl:float=3.6) -> void:
    if shots.size() >= MAX_SHOTS - 4:
        return
    shots.append({"pos":origin,"dir":heading.normalized(),"life":ttl,"damage":damage,
        "size":size,"hostile":true,"vfx":art,"velocity":speed,"hit":{}})

func _boss_ring(at:Vector2, count:int, art:String, damage:float, speed:float, rotation:float=0.0) -> void:
    for i in range(count):
        var heading=Vector2.from_angle(rotation + TAU * float(i)/maxf(1.0,float(count)))
        _boss_shot(at,heading,art,0.84,damage,speed)

func _boss_fan(at:Vector2,count:int,art:String,damage:float,speed:float,width:float) -> void:
    var aim=(player_pos-at).normalized()
    for i in range(count):
        var offset=(float(i)-float(count-1)/2.0)*width
        _boss_shot(at,aim.rotated(offset),art,0.78,damage,speed)

func _boss_telegraph(kind:String,origin:Vector2,heading:Vector2,windup:float,length:float,width:float,damage:float) -> void:
    boss_telegraphs.append({"kind":kind,"pos":origin,"dir":heading.normalized(),
        "windup":windup,"duration":windup,"length":length,"width":width,"damage":damage})

func _boss_attack(phase:int) -> void:
    var at:Vector2=boss["pos"]
    var aim:Vector2=(player_pos-at).normalized()
    var index:int=boss["attack_index"]
    boss["attack_index"]=index+1
    var actor=boss["actor"]
    if phase==1:
        actor.pose_action="200" if index%2==0 else "220"
        actor.pose_time=0.55
        if index%2==0:
            _boss_fan(at,9,"senbon",10.0,280.0,0.113)
            boss_attack_history.append("P1 poison senbon fan")
            _flash("SASORI: POISONED SENBON",1.1)
        else:
            _boss_ring(at,11,"chakra",11.0,196.0,float(index)*0.38)
            boss_attack_history.append("P1 puppet wheel")
            _flash("SASORI: PUPPET WHEEL",1.1)
        boss["attack_cd"]=2.7
    elif phase==2:
        actor.pose_action="300" if index%2==0 else "310"
        actor.pose_time=0.78
        if index%2==0:
            _boss_telegraph("sand_lane",at,aim,1.25,740.0,112.0,24.0)
            boss_attack_history.append("P2 iron sand sweep")
            _flash("THIRD KAZEKAGE: IRON SAND",1.4)
        else:
            _boss_ring(at,15,"sand",13.0,238.0,float(index)*0.31)
            boss_attack_history.append("P2 iron sand needles")
            _flash("SATETSU: KAIHOU",1.1)
        boss["attack_cd"]=2.4
    else:
        actor.pose_action="3000" if index%2==0 else "4100"
        actor.pose_time=0.9
        if index%3==0:
            _boss_telegraph("poison_pool",player_pos+Vector2(55,0),Vector2.RIGHT,1.45,115.0,115.0,22.0)
            _boss_ring(at,16,"poison",12.0,242.0,float(index)*0.29)
            boss_attack_history.append("P3 poisoned core")
            _flash("SASORI: POISONED CORE",1.2)
        elif index%3==1:
            _boss_telegraph("blast",player_pos,Vector2.RIGHT,1.25,126.0,126.0,25.0)
            _boss_fan(at,11,"senbon",14.0,330.0,0.12)
            boss_attack_history.append("P3 puppet legion")
            _flash("SASORI: HUNDRED PUPPETS",1.1)
        else:
            _boss_telegraph("sand_lane",at,aim,0.95,800.0,134.0,25.0)
            _boss_ring(at,18,"sand",14.0,250.0,float(index)*0.32)
            boss_attack_history.append("P3 hundred puppet storm")
            _flash("AKAHIGI: HYAKKI NO SOEN",1.3)
        boss["attack_cd"]=2.15
    _sfx("boss.wav")

func _update_boss(dt:float) -> void:
    if boss.is_empty() or boss.get("hp",0.0)<=0.0:return
    var at:Vector2=boss["pos"]
    var dir=(player_pos-at).normalized()
    var fraction:float= float(boss["hp"])/maxf(1.0,float(boss["max_hp"]))
    var phase=1 if fraction>0.66 else 2 if fraction>0.33 else 3
    if phase != boss_phase_reached:
        boss_phase_reached=phase
        boss["phase_pause"]=1.5
        boss["attack_cd"]=2.5
        boss_telegraphs.clear()
        boss["actor"].pose_action="300" if phase==2 else "3000"
        boss["actor"].pose_time=1.35
        boss["actor"].form_tint = Color(0.92,0.92,0.95) if phase==1 else Color(0.86,0.92,1.0) if phase==2 else Color(1.0,0.82,0.86)
        boss["actor"].sprite_scale = 1.62 if phase==1 else 1.74 if phase==2 else 1.86
        _flash("PHASE II  /  THE THIRD KAZEKAGE" if phase==2 else "PHASE III  /  HUNDRED PUPPETS",2.6)
        _sfx("transform.mp3")
        _log("Sasori enters phase %d at %.1f (HP %.0f)" % [phase,clock,boss["hp"]])
    boss["phase"]=phase
    if boss["phase_pause"]>0:
        boss["phase_pause"]-=dt
    else:
        var dist=at.distance_to(player_pos)
        if dist>180.0:
            at+=dir*(55.0 + phase*9.0)*dt
        elif dist<118.0:
            at-=dir*52.0*dt
    boss["pos"]=at
    boss["actor"].position=at
    boss["actor"].moving=boss["phase_pause"]<=0.0
    boss["actor"].facing=signf(dir.x) if dir.x!=0 else 1.0
    boss["actor"].tick(visual_delta)
    boss["attack_cd"]-=dt
    if boss["attack_cd"]<=0 and boss["phase_pause"]<=0:
        _boss_attack(phase)

func _update_boss_telegraphs(dt:float) -> void:
    for h in boss_telegraphs.duplicate():
        h["windup"]-=dt
        if h["windup"]>0:continue
        var at:Vector2=h["pos"]
        if h["kind"]=="sand_lane":
            var start:Vector2=at
            var ending:Vector2=at+(h["dir"] as Vector2)*float(h["length"])
            var closest=Geometry2D.get_closest_point_to_segment(player_pos,start,ending)
            if closest.distance_to(player_pos)<float(h["width"])*0.5 and invulnerable<=0 and not godmode:
                player_hp -= float(h["damage"])
                invulnerable=0.75
            for j in range(6):
                _boss_shot(start + (ending-start)*float(j)/8.0, h["dir"],"sand",1.15,9.0,254.0,1.4)
        else:
            if player_pos.distance_to(at)<float(h["width"])*0.5 and invulnerable<=0 and not godmode:
                player_hp-=float(h["damage"])
                invulnerable=0.75
            if h["kind"]=="blast":
                _boss_ring(at,8,"blast",12.0,220.0)
            else:
                _boss_ring(at,10,"poison",10.0,195.0)
        boss_telegraphs.erase(h)
        _sfx("impact.wav")


func _update_projectiles(dt:float) -> void:
    for shot in shots.duplicate():
        shot["life"]-=dt
        var hostile:bool=shot.get("hostile",false)
        var travel=float(shot.get("velocity",205.0)) if hostile else float(shot.get("velocity",355.0+player_form*43.0))
        shot["pos"]+=shot["dir"]*travel*dt
        if shot["life"]<=0:
            shots.erase(shot)
            continue
        if hostile:
            if shot["pos"].distance_squared_to(player_pos)<400 and invulnerable<=0:
                if not godmode:
                    player_hp-=shot["damage"]
                    invulnerable=0.42
                shots.erase(shot)
            continue
        var radius=(7.0 if str(shot.get("kind","" )).begins_with("kunai") else 15.0)*float(shot.get("size",1.0))
        var touched=false
        for e in enemies.duplicate():
            if not enemies.has(e): continue
            var ref=int(e["actor"].get_instance_id())
            if shot["hit"].has(ref):continue
            if shot["pos"].distance_squared_to(e["pos"])<(radius+14.0)*(radius+14.0):
                shot["hit"][ref]=true
                _damage_target(e,shot["damage"])
                _projectile_impact(shot,shot["pos"])
                shot["pierced"]+=1
                touched=true
                var penetration := int(upgrades["kunai_pierce"]) if str(shot.get("kind","")).begins_with("kunai") else int(upgrades["pierce"])
                if int(shot["pierced"])>penetration or shot.get("kind","")=="shuriken":
                    shots.erase(shot)
                    break
        if shots.has(shot) and boss_active and boss.get("hp",0.0)>0.0:
            var ref=int(boss["actor"].get_instance_id())
            if not shot["hit"].has(ref) and shot["pos"].distance_squared_to(boss["pos"])<(radius+42.0)*(radius+42.0):
                shot["hit"][ref]=true
                _damage_target(boss,shot["damage"])
                _projectile_impact(shot,shot["pos"])
                if shots.has(shot):shots.erase(shot)

func _update_drops(dt:float) -> void:
    for d in drops.duplicate():
        var at:Vector2=d["pos"]
        var distance=at.distance_to(player_pos)
        if distance<(100.0+float(upgrades["magnet"])*42.0) and distance>0:
            d["pos"]+= (player_pos-at).normalized()*dt*minf(390.0,1400.0/(distance+15.0)*50)
        if distance>26.0:continue
        drops.erase(d)
        if d["type"]=="xp":
            exp_value+=d["value"]
            stat_exp_collected += int(d["value"])
            if exp_value>=exp_needed:
                exp_value-=exp_needed
                level+=1
                exp_needed=22.0+float(level)*12.5
                _open_upgrade(false)
                return
        elif d["type"]=="heal":
            player_hp=minf(PLAYER_MAX_HP+float(upgrades["max_hp"])*18.0,player_hp+float(d["value"]))
        else:
            _open_upgrade(true)
            return

func _update_clones(dt:float) -> void:
    for c in clones.duplicate():
        c["life"]-=dt
        var chase_target=_closest_target(c["pos"],375.0)
        if not chase_target.is_empty():
            c["pos"]=(c["pos"] as Vector2).move_toward(chase_target["pos"],68.0*dt)
            if absf((chase_target["pos"]-c["pos"]).x)>1: c["actor"].facing=signf((chase_target["pos"]-c["pos"]).x)
        else:
            c["pos"]=(c["pos"] as Vector2).move_toward(player_pos,82.0*dt)
        c["actor"].position=c["pos"]
        c["actor"].moving=true
        c["actor"].tick(visual_delta)
        c["fire_cd"]-=dt
        if c["fire_cd"]<=0 and not chase_target.is_empty() and shots.size()<MAX_SHOTS:
            var aim:Vector2=(chase_target["pos"]-c["pos"]).normalized()
            var assist_rasengan := int(upgrades["clones"])>=2 and int(upgrades["rasengan"])>0 and rng.randi_range(0,4)==0
            shots.append({"pos":c["pos"]+Vector2(0,-25),"dir":aim,"life":0.95,
                "damage":(20.0+float(upgrades["clones"])*4.0)*TRANSFORM_DAMAGE_BOOST[player_form] if assist_rasengan else (9.0+float(upgrades["clones"])*2.5)*TRANSFORM_DAMAGE_BOOST[player_form],
                "size":1.0 if assist_rasengan else 0.85,"kind":"rasengan" if assist_rasengan else "kunai", "pierced":0,"hit":{},"velocity":425.0 if assist_rasengan else 495.0})
            c["fire_cd"]=1.55
        if c.get("rendan_hits",0)>0:
            c["rendan_cd"]-=dt
            if c["rendan_cd"]<=0:
                var victim=_closest_target(c["pos"],430.0)
                if not victim.is_empty():
                    c["pos"]=(c["pos"] as Vector2).move_toward(victim["pos"],115.0)
                    _aoe_damage(victim["pos"],36.0,((18.0+float(upgrades["naruto_rendan"])*12.0)*(1.0+float(upgrades["clones"])*0.22))*TRANSFORM_DAMAGE_BOOST[player_form])
                    if fx.size()<MAX_FX:
                        fx.append({"pos":victim["pos"],"life":0.24,"max":0.24,"radius":34.0,"kind":"rendan"})
                    c["actor"].pose_action="210" if c["actor"].actions.has("210") else "200"
                    c["actor"].pose_time=0.32
                    c["actor"].position=c["pos"]
                    c["rendan_hits"]-=1
                    c["rendan_cd"]=0.34
                else:
                    c["rendan_hits"]=0
        if c["life"]<=0 or c["hp"]<=0:
            c["actor"].queue_free()
            clones.erase(c)

func _spawn_clones() -> void:
    if clone_cooldown>0:return
    clone_cooldown=maxf(9.5,23.0-float(upgrades["clones"])*2.2)
    for i in range(2+int(upgrades["clones"])):
        var at=player_pos+Vector2.from_angle(TAU*i/maxf(2,2+int(upgrades["clones"]))) * 52.0
        var actor = _enemy_actor(["naruto_base","naruto_sage","naruto_kcm"][player_form],at,Color("e8ae48"))
        actor.form_tint=Color(0.77,0.9,1,0.80)
        clones.append({"pos":at,"life":5.0+float(upgrades["clones"])*0.8,
                       "hp":90.0,"actor":actor,"fire_cd":rng.randf_range(0.18,0.7),
                       "rendan_hits":(1+int(upgrades["naruto_rendan"])) if int(upgrades["naruto_rendan"])>0 else 0,
                       "rendan_cd":0.2+float(i)*0.1})
    _flash("NARUTO RENDAN!" if int(upgrades["naruto_rendan"])>0 else "KAGE BUNSHIN")
    _sfx("clone.wav")

func _update_fx(dt:float) -> void:
    event_time=maxf(0.0,event_time-dt)
    for v in fx.duplicate():
        v["life"]-=dt
        if v["life"]<=0: fx.erase(v)
    for k in kawarimi_fx.duplicate():
        k["life"]-=dt
        if k["life"]<=0:kawarimi_fx.erase(k)


func _update_hazards(dt:float) -> void:
    if boss_active:
        quicksand_zones.clear()
        return
    hazard_timer -= dt
    if hazard_timer <= 0.0 and quicksand_zones.size() < 4:
        var pos = player_pos + Vector2(rng.randf_range(-420.0,420.0), rng.randf_range(-300.0,300.0))
        quicksand_zones.append({"pos": pos, "radius": rng.randf_range(44.0,68.0), "life": rng.randf_range(10.0,15.0), "pulse": rng.randf_range(0.0,TAU)})
        hazard_timer = rng.randf_range(4.0,7.0)
    for q in quicksand_zones.duplicate():
        q["life"] -= dt
        q["pulse"] += dt * 2.4
        if q["life"] <= 0.0:
            quicksand_zones.erase(q)

func _update_oiroke(dt:float) -> void:
    var power=int(upgrades.get("oiroke",0))
    if power <= 0: return
    oiroke_cd -= dt
    if oiroke_cd <= 0.0:
        oiroke_time=3.8+float(power)*0.7
        oiroke_cd=maxf(10.0,23.0-float(power)*3.2)
        oiroke_pos=player_pos
        oiroke_hits.clear()
        _flash("OIROKE NO JUTSU!",1.5)
        _sfx("clone.wav")
    if oiroke_time<=0.0:return
    oiroke_time=maxf(0.0,oiroke_time-dt)
    oiroke_pos=oiroke_pos.move_toward(player_pos,dt*92.0)
    var radius=74.0+float(power)*18.0
    for e in enemies.duplicate():
        if not enemies.has(e): continue
        var uid=int(e["actor"].get_instance_id())
        var inside=(e["pos"] as Vector2).distance_squared_to(oiroke_pos)<radius*radius
        if inside and not oiroke_hits.has(uid):
            oiroke_hits[uid]=true
            _damage_target(e,(27.0+float(power)*22.0)*TRANSFORM_DAMAGE_BOOST[player_form])
            e["stagger"]=maxf(float(e.get("stagger",0.0)),1.4+float(power)*0.5)
            if fx.size()<MAX_FX:fx.append({"pos":e["pos"],"life":0.34,"max":0.34,"kind":"charm","radius":22.0})
    if boss_active and boss.get("hp",0.0)>0.0 and not oiroke_hits.has(-1):
        if (boss["pos"] as Vector2).distance_squared_to(oiroke_pos)<radius*radius:
            oiroke_hits[-1]=true
            _damage_target(boss,(27.0+float(power)*22.0)*TRANSFORM_DAMAGE_BOOST[player_form])

func _pool_upgrades() -> Array[String]:
    var pool:Array[String]=[]
    for key in JUTSU.keys():
        if int(upgrades[key])>=int(JUTSU[key]["max"]):continue
        if key in ["oodama","rasenrendan","rasenshuriken","rasenornado","sage_focus","chakra_flow"] and int(upgrades.get("rasengan",0))==0:continue
        pool.append(key)
    return pool

func _pick_rarity(scroll:bool) -> int:
    var r=rng.randf()
    if scroll:
        return 3 if r<0.04 else 2 if r<0.24 else 1 if r<0.73 else 0
    return 3 if r<0.007 else 2 if r<0.075 else 1 if r<0.35 else 0

func _select_skill(pool:Array[String],scroll:bool) -> String:
    var tier=_pick_rarity(scroll)
    var matches:Array[String]=[]
    for key in pool:
        if int(JUTSU[key]["tier"])==tier:matches.append(key)
    # If selected rarity is exhausted, nearest remaining tier wins.
    if matches.is_empty():
        var smallest=10
        for key in pool: smallest=mini(smallest,absi(int(JUTSU[key]["tier"])-tier))
        for key in pool:
            if absi(int(JUTSU[key]["tier"])-tier)==smallest:matches.append(key)
    return matches[rng.randi_range(0,matches.size()-1)]

func _open_upgrade(scroll:bool) -> void:
    var pool=_pool_upgrades()
    if pool.is_empty(): return
    picking=true
    scroll_count+=int(scroll)
    ui_view.from_scroll=scroll
    selected_cards.clear()
    for i in range(3):
        if pool.is_empty(): break
        var pick=_select_skill(pool,scroll)
        if i==0 and int(upgrades.get("rasengan",0))==0 and (level>=3 or clock>=75.0) and pool.has("rasengan"):
            pick="rasengan"
        pool.erase(pick)
        selected_cards.append({"stat":pick,"tier":JUTSU[pick]["tier"]})
    _sfx("gacha.wav" if scroll else "upgrade.wav")

func _choose_card(index:int) -> void:
    if not picking or index<0 or index>=selected_cards.size():return
    var c=selected_cards[index]
    var stat:String=c["stat"]
    upgrades[stat]+=1
    if stat=="max_hp":
        player_hp=minf(PLAYER_MAX_HP+float(upgrades["max_hp"])*18.0,player_hp+32.0)
    if stat=="rasengan":
        rasengan_timer=0.4
    if stat=="oiroke":
        oiroke_cd=1.3
    if c["tier"]>=2:
        _flash("ODKRYTO: "+str(JUTSU[stat]["name"]),2.4)
    picking=false
    _sfx("reveal.wav")

func _update_hud() -> void:
    # Stable depth ordering keeps feet and contact shadows coherent in crowds.
    player.z_index=clampi(int(player_pos.y-camera.position.y)+1000,1,2000)
    for e in enemies: e["actor"].z_index=clampi(int(e["pos"].y-camera.position.y)+1000,1,2000)
    for c in clones: c["actor"].z_index=clampi(int(c["pos"].y-camera.position.y)+1000,1,2000)
    if boss.has("actor"): boss["actor"].z_index=clampi(int(boss["pos"].y-camera.position.y)+1000,1,2000)

func _finish(victory:bool) -> void:
    if finished:return
    finished=true
    picking=false
    ui_view.victory=victory
    _log("run ended: %s at %.1f, level %d" % ["VICTORY" if victory else "DEFEAT",clock,level])

func _sfx(file:String) -> void:
    if muted:return
    var path="res://assets/audio/"+file
    if not FileAccess.file_exists(path): return
    # Critical voice effects must play even during rapid-fire combat.
    var output:AudioStreamPlayer = special_sfx_player if file in ["transform.mp3","clone.wav"] else sfx_player
    if output==sfx_player and output.playing and output.get_playback_position()<0.07:return
    var bytes := FileAccess.get_file_as_bytes(path)
    if file.to_lower().ends_with(".mp3"):
        output.stream = AudioStreamMP3.load_from_buffer(bytes)
    else:
        output.stream = AudioStreamWAV.load_from_buffer(bytes)
    output.volume_db=-5.0 if output==special_sfx_player else -7.0
    output.play()

func _tile_id(x:int,y:int)->int:
    var hash_value=int(x*92837111)^int(y*689287499)
    return posmod(hash_value,tiles.size()) if tiles.size()>0 else 0

func _draw() -> void:
    var left:=player_pos-Vector2(610,380)
    var right:=player_pos+Vector2(610,380)
    if stage_ground!=null:
        for yy in range(int(floor(left.y/1024.0)),int(ceil(right.y/1024.0))+1):
            for xx in range(int(floor(left.x/1024.0)),int(ceil(right.x/1024.0))+1):
                draw_texture(stage_ground,Vector2(float(xx)*1024.0,float(yy)*1024.0))
    else:
        draw_rect(Rect2(left,right-left),Color("b9905b"),true)
    if not prop_textures.is_empty():
        for yy in range(int(floor(left.y/190.0))-1,int(ceil(right.y/190.0))+2):
            for xx in range(int(floor(left.x/190.0))-1,int(ceil(right.x/190.0))+2):
                var hash_value=posmod(xx*23819+yy*47149,7919)
                if hash_value%5 != 0:continue
                var prop=prop_textures[hash_value%prop_textures.size()]
                var place=Vector2(float(xx)*190.0+float(hash_value%69),float(yy)*190.0+float(hash_value%57))
                var prop_size:Vector2=prop.get_size()*1.8
                draw_texture_rect(prop,Rect2(place-prop_size*Vector2(0.5,1.0),prop_size),false)
    for q in quicksand_zones:
        var pulse = 0.5 + 0.5 * sin(float(q["pulse"]))
        var rad = float(q["radius"])
        draw_circle(q["pos"], rad, Color(0.45,0.31,0.12,0.34))
        draw_arc(q["pos"], rad * 0.78, 0, TAU, 42, Color(0.75,0.58,0.28,0.75), 2.0)
        for ring in [0.34,0.58,0.82]:
            draw_arc(q["pos"], rad * ring, pulse + ring * TAU, pulse + ring * TAU + PI * 1.15, 24, Color(0.88,0.74,0.42,0.55), 1.6)
    # Telegraphs are rendered beneath actors/projectiles and remain readable under heavy VFX.
    for h in boss_telegraphs:
        var remain:float=float(h["windup"])/maxf(0.01,float(h["duration"]))
        var warn=Color("eb593d") if h["kind"]!="poison_pool" else Color("ae52b7")
        warn.a=0.16+0.29*(1.0-remain)
        if h["kind"]=="sand_lane":
            var heading:Vector2=h["dir"]
            var ending:Vector2=h["pos"]+heading*float(h["length"])
            draw_line(h["pos"],ending,warn,float(h["width"]))
            draw_line(h["pos"],ending,Color("f2c38d"),2.5)
        else:
            draw_circle(h["pos"],float(h["width"])*0.50,warn)
            draw_arc(h["pos"],float(h["width"])*0.5,0,TAU,48,Color("ffc69a"),2.5)
    for d in drops:
        var at:Vector2=d["pos"]
        if d["type"]=="xp":
            var pulse := 0.5 + 0.5 * sin(hostile_orb_clock * 6.0 + at.x * 0.02)
            draw_circle(at,7.5 + pulse*1.6,Color(0.13,0.82,0.97,0.16))
            draw_circle(at,5.0 + pulse*0.9,Color("4ee8ff"))
            draw_circle(at,2.3,Color.WHITE)
            draw_arc(at,9.8 + pulse*1.4,hostile_orb_clock*3.2,hostile_orb_clock*3.2+TAU*0.72,22,Color("9cf7ff"),1.5)
        elif d["type"]=="heal":
            draw_circle(at,8.3,Color("ef6f88"))
            draw_circle(at,4.0,Color("ffd4dc"))
            draw_line(at+Vector2(-4,0),at+Vector2(4,0),Color.WHITE,2.0)
            draw_line(at+Vector2(0,-4),at+Vector2(0,4),Color.WHITE,2.0)
        else:
            var wig := 0.6 + 0.4*sin(hostile_orb_clock*4.0)
            draw_circle(at,12.0,Color(0.84,0.70,0.30,0.18))
            draw_circle(at,8.0,Color("d8b45b"))
            draw_rect(Rect2(at-Vector2(5,7),Vector2(10,14)),Color(0.40,0.23,0.07,0.88),false,2.0)
            draw_line(at+Vector2(-4,0),at+Vector2(4,0),Color(0.83,0.92,0.95,wig),2.0)
    for k in kawarimi_fx:
        var fade=float(k["life"])/maxf(0.01,float(k["max"]))
        var origin:Vector2=k["pos"]
        if kawarimi_log!=null:
            draw_texture_rect(kawarimi_log,Rect2(origin-Vector2(21,61.5),kawarimi_log.get_size()*1.5),false,Color(1.0,1.0,1.0,fade))
        else:
            draw_rect(Rect2(origin-Vector2(11,29),Vector2(22,37)),Color(0.48,0.25,0.1,fade),true)
        draw_arc(origin,35.0+(1.0-fade)*35.0,0,TAU,28,Color(0.93,0.94,0.92,fade*0.7),3.0)
    if oiroke_time>0:
        var radius=74.0+float(upgrades["oiroke"])*18.0
        draw_circle(oiroke_pos,radius,Color(0.85,0.32,0.7,0.10))
        draw_arc(oiroke_pos,radius,0,TAU,70,Color(1.0,0.59,0.82,0.86),3.0)
        for j in range(8):
            var pos=oiroke_pos+Vector2.from_angle(float(j)*TAU/8.0+hostile_orb_clock*0.6)*radius
            draw_circle(pos,4.5,Color(1.0,0.65,0.82))
        draw_arc(oiroke_pos,26.0,0,TAU,36,Color(1.0,0.73,0.9),3.0)
    for s in shots:
        if not s.get("hostile",false):
            if str(s.get("kind","")).begins_with("kunai"):
                var tex:Texture2D=item_art.get("kunai",null)
                if tex!=null:
                    var position:Vector2=s["pos"]
                    var direction:Vector2=s["dir"]
                    var tint:Color=s.get("tint",Color.WHITE)
                    var size:Vector2=tex.get_size()*(1.7 if s["kind"]=="kunai_explosive" else 1.45)
                    draw_set_transform(position,direction.angle(),Vector2.ONE)
                    draw_texture_rect(tex,Rect2(-size*0.5,size),false,Color.WHITE)
                    if player_form>0:
                        draw_line(Vector2(-30,0),Vector2(-3,0),Color(tint.r,tint.g,tint.b,0.65),3.0)
                    draw_set_transform(Vector2.ZERO,0.0,Vector2.ONE)
                continue
            var sprites=shuriken_frames if s.get("kind","")=="shuriken" else rasengan_frames
            if sprites.is_empty():continue
            var frame=sprites[int(clock*21)%sprites.size()]
            var scale=1.7 if s.get("kind","")=="shuriken" else 1.0
            var r=37.0*float(s.get("size",1.0))*scale
            var base_tint:Color = s.get("tint", Color.WHITE)
            var tint=Color("ffe282") if s.get("critical",false) else base_tint
            draw_texture_rect(frame,Rect2(s["pos"]-Vector2.ONE*r/2,Vector2.ONE*r),false,tint)
        else:
            var item_key := str(s.get("item_vfx",""))
            var item_tex:Texture2D=item_art.get(item_key,null)
            if item_tex!=null:
                var radius=21.0 if item_key in ["shuriken","small_shuriken","chakra_bomb"] else 29.0
                var dims:Vector2=item_tex.get_size()*radius/maxf(item_tex.get_width(),item_tex.get_height())
                draw_set_transform(s["pos"],(s["dir"] as Vector2).angle(),Vector2.ONE)
                draw_texture_rect(item_tex,Rect2(-dims*0.5,dims),false,Color.WHITE)
                draw_set_transform(Vector2.ZERO,0.0,Vector2.ONE)
                continue
            var effect_id := str(s.get("vfx",""))
            var images:Array = boss_vfx.get(effect_id,[])
            if not images.is_empty():
                var frame:Texture2D=images[int(hostile_orb_clock*13.0)%images.size()]
                var amount:float=54.0*float(s.get("size",1.0))
                if effect_id=="senbon":amount=74.0*float(s.get("size",1.0))
                if effect_id=="sand":amount=64.0*float(s.get("size",1.0))
                draw_set_transform(s["pos"],(s["dir"] as Vector2).angle(),Vector2.ONE)
                var dims:Vector2=frame.get_size()*amount/maxf(frame.get_width(),frame.get_height())
                draw_texture_rect(frame,Rect2(-dims*0.5,dims),false)
                draw_set_transform(Vector2.ZERO,0.0,Vector2.ONE)
                continue
            var direction:Vector2=s["dir"]
            var style := str(s.get("style","needle"))
            if style == "burst":
                draw_circle(s["pos"],7.0,Color(0.88,0.99,0.78,0.25))
                draw_circle(s["pos"],4.8,Color("b8f56c"))
                draw_arc(s["pos"],8.5,hostile_orb_clock*7.0,hostile_orb_clock*7.0+TAU*0.8,18,Color("efffc6"),1.7)
            else:
                var side:Vector2 = Vector2(-direction.y,direction.x)
                var tail:Vector2 = s["pos"]-direction*11
                var tip:Vector2 = s["pos"]+direction*12
                var pts := PackedVector2Array([tail-side*3.0, tail+side*3.0, tip])
                draw_colored_polygon(pts,Color("cce7a5"))
                draw_line(tail,tip,Color("efffc6"),2.0)
                draw_circle(tail,2.6,Color("6ab04e"))
    for tornado in tornadoes:
        if tornado_frames.is_empty():continue
        var frame=tornado_frames[int(clock*16)%tornado_frames.size()]
        var r=92.0
        draw_texture_rect(frame,Rect2(tornado["pos"]-Vector2.ONE*r/2,Vector2.ONE*r),false)

    for v in fx:
        if low_fx and v["kind"]!="pulse":continue
        var life=float(v["life"])/maxf(0.001,float(v["max"]))
        var tint=Color("ef91cd") if v["kind"]=="charm" else Color("e9a55c") if v["kind"]=="rendan" else Color("f6d56c") if v["kind"]=="critical" else Color("77efb8") if v["kind"]=="heal" else Color("f4c657") if v["kind"]=="pulse" and player_form==2 else Color("e58b57") if v["kind"]=="pulse" else Color("95eaff")
        tint.a=life*0.75
        var radius=float(v.get("radius",110.0))*(1.0-life) if v["kind"]!="pulse" else 110.0*(1.0-life)
        if v["kind"]=="aoe": radius=float(v.get("radius",120.0))*(1.0-life*0.9)
        draw_arc(v["pos"],maxf(1.0,radius),0,TAU,56,tint,5.0)
    if transform_pause > 0.0:
        var t := transform_pause / maxf(0.001, transform_total)
        draw_circle(player_pos+Vector2(0,-36), 145.0, Color(1,0.92,0.65,0.09))
        draw_arc(player_pos+Vector2(0,-36), 86.0 + (1.0-t)*42.0, 0, TAU, 64, Color(1,0.86,0.47,0.95), 4.0)
        if not burst_frames.is_empty():
            var idx := int((1.0 - t) * float(burst_frames.size()-1))
            idx = clampi(idx,0,burst_frames.size()-1)
            var frame := burst_frames[idx]
            draw_texture_rect(frame, Rect2(player_pos-Vector2(92,128), Vector2(184,184)), false, Color(1,1,1,0.92))

